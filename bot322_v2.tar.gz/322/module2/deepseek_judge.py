#!/usr/bin/env python3
"""
DeepSeek Judge - LLM для разрешения сложных случаев матчинга
Используется только в "серой зоне" (score 55-84)
"""

import os
from typing import Dict, List, Optional
from openai import OpenAI


class DeepSeekJudge:
    """LLM судья для сложных случаев матчинга"""
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.environ.get('DEEPSEEK_API_KEY')
        if not self.api_key:
            print("⚠️ DeepSeek API key not set. LLM judge disabled.")
            self.client = None
        else:
            self.client = OpenAI(
                api_key=self.api_key,
                base_url="https://api.deepseek.com"
            )
    
    def judge(self, kalshi_event: Dict, candidates: List[Dict]) -> Optional[int]:
        """
        Попросить LLM выбрать лучшего кандидата.
        
        Args:
            kalshi_event: событие Kalshi
            candidates: список кандидатов Polymarket (топ-5)
        
        Returns:
            индекс лучшего кандидата (0-4) или None если нет совпадения
        """
        if not self.client:
            return None
        
        if not candidates:
            return None
        
        # Формируем промпт
        prompt = self._build_prompt(kalshi_event, candidates)
        
        try:
            response = self.client.chat.completions.create(
                model="deepseek-chat",
                messages=[
                    {
                        "role": "system",
                        "content": """You are a sports event matching expert. Your task is to determine if a Kalshi event matches any of the Polymarket candidates.

Rules:
1. Events match if they are THE SAME sports match/game
2. Team names may be written differently (e.g., "Warriors" = "Golden State Warriors")
3. Times should be within 2 hours of each other
4. League/sport must match (NBA with NBA, NHL with NHL, etc.)
5. If no candidate matches, say "NONE"

Respond with ONLY the candidate number (1-5) or "NONE". No explanation needed."""
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                max_tokens=10,
                temperature=0
            )
            
            answer = response.choices[0].message.content.strip().upper()
            
            # Парсим ответ
            if answer == "NONE":
                return None
            
            try:
                idx = int(answer) - 1  # Конвертируем 1-5 в 0-4
                if 0 <= idx < len(candidates):
                    return idx
            except ValueError:
                pass
            
            return None
            
        except Exception as e:
            print(f"⚠️ DeepSeek error: {e}")
            return None
    
    def _build_prompt(self, kalshi_event: Dict, candidates: List[Dict]) -> str:
        """Построить промпт для LLM"""
        lines = []
        
        # Kalshi событие
        lines.append("KALSHI EVENT:")
        lines.append(f"  Title: {kalshi_event.get('original_title', 'N/A')}")
        lines.append(f"  Teams: {kalshi_event.get('team1', 'N/A')} vs {kalshi_event.get('team2', 'N/A')}")
        lines.append(f"  League: {kalshi_event.get('league', 'N/A')}")
        lines.append(f"  Time: {kalshi_event.get('start_time', 'N/A')}")
        lines.append("")
        
        # Кандидаты
        lines.append("POLYMARKET CANDIDATES:")
        for i, cand in enumerate(candidates[:5], 1):
            lines.append(f"  {i}. {cand.get('original_title', 'N/A')}")
            lines.append(f"     Teams: {cand.get('team1', 'N/A')} vs {cand.get('team2', 'N/A')}")
            lines.append(f"     League: {cand.get('league', 'N/A')}")
            lines.append(f"     Time: {cand.get('start_time', 'N/A')}")
            lines.append("")
        
        lines.append("Which candidate (1-5) matches the Kalshi event? Or NONE if no match.")
        
        return "\n".join(lines)


# Тест
if __name__ == "__main__":
    # Тест без API ключа
    judge = DeepSeekJudge()
    
    kalshi = {
        'original_title': 'Warriors at Timberwolves',
        'team1': 'warriors',
        'team2': 'timberwolves',
        'league': 'nba',
        'start_time': '2026-01-25T03:30:00+00:00'
    }
    
    candidates = [
        {
            'original_title': 'Lakers vs. Celtics',
            'team1': 'lakers',
            'team2': 'celtics',
            'league': 'nba',
            'start_time': '2026-01-25T04:00:00+00:00'
        },
        {
            'original_title': 'Warriors vs. Timberwolves',
            'team1': 'warriors',
            'team2': 'timberwolves',
            'league': 'nba',
            'start_time': '2026-01-25T03:30:00+00:00'
        },
        {
            'original_title': 'Heat vs. Jazz',
            'team1': 'heat',
            'team2': 'jazz',
            'league': 'nba',
            'start_time': '2026-01-25T05:00:00+00:00'
        }
    ]
    
    print("Prompt that would be sent to DeepSeek:")
    print("=" * 60)
    print(judge._build_prompt(kalshi, candidates))
    print("=" * 60)
    
    # Если есть API ключ, можно протестировать
    if judge.client:
        result = judge.judge(kalshi, candidates)
        print(f"\nDeepSeek answer: {result}")
