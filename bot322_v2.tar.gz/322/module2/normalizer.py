#!/usr/bin/env python3
"""
Normalizer - нормализация названий команд + работа с aliases
"""

import json
import os
from typing import Dict, Optional, List
from rapidfuzz import fuzz, process


class TeamNormalizer:
    """Нормализация названий команд с использованием aliases и fuzzy matching"""
    
    def __init__(self, aliases_path: str = None):
        if aliases_path is None:
            aliases_path = os.path.join(os.path.dirname(__file__), 'aliases.json')
        
        self.aliases_path = aliases_path
        self.aliases = self._load_aliases()
        self._build_reverse_index()
    
    def _load_aliases(self) -> Dict:
        """Загрузить aliases из файла"""
        try:
            with open(self.aliases_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            return {}
    
    def _save_aliases(self):
        """Сохранить aliases в файл"""
        with open(self.aliases_path, 'w', encoding='utf-8') as f:
            json.dump(self.aliases, f, indent=2, ensure_ascii=False)
    
    def _build_reverse_index(self):
        """Построить обратный индекс: alias -> canonical name"""
        self.reverse_index = {}  # alias -> (league, canonical)
        self.all_names = []  # все известные имена для fuzzy search
        
        for league, teams in self.aliases.items():
            for canonical, aliases in teams.items():
                # Добавляем canonical
                self.reverse_index[canonical.lower()] = (league, canonical)
                self.all_names.append(canonical.lower())
                
                # Добавляем все aliases
                for alias in aliases:
                    self.reverse_index[alias.lower()] = (league, canonical)
                    self.all_names.append(alias.lower())
    
    def normalize(self, team_name: str, league: str = None) -> str:
        """
        Нормализовать название команды.
        Возвращает canonical name или очищенное оригинальное название.
        """
        if not team_name:
            return ''
        
        # Очищаем название
        cleaned = self._clean_name(team_name)
        
        # Пробуем найти в reverse_index (точное совпадение)
        if cleaned in self.reverse_index:
            found_league, canonical = self.reverse_index[cleaned]
            # Если лига указана, проверяем совпадение
            if league and found_league != league:
                # Лига не совпадает, но может быть одинаковое название в разных лигах
                pass
            return canonical
        
        # Пробуем fuzzy match ТОЛЬКО если название короткое (аббревиатура)
        # Для длинных названий не используем fuzzy - слишком много ложных срабатываний
        if len(cleaned) <= 6 and self.all_names:
            matches = process.extract(cleaned, self.all_names, scorer=fuzz.ratio, limit=3)
            if matches and matches[0][1] >= 90:  # score >= 90% для коротких
                best_match = matches[0][0]
                if best_match in self.reverse_index:
                    _, canonical = self.reverse_index[best_match]
                    return canonical
        
        # Не нашли - возвращаем очищенное название
        return cleaned
    
    def _clean_name(self, name: str) -> str:
        """Очистить название команды"""
        name = name.lower().strip()
        
        # Убираем общие суффиксы/префиксы
        remove_patterns = [
            ' fc', ' bc', ' sc', ' ac',
            'fc ', 'bc ', 'sc ', 'ac ',
            ' united', ' city',
            ' state', ' st.',
            ' university', ' college',
        ]
        
        for pattern in remove_patterns:
            name = name.replace(pattern, ' ')
        
        # Убираем множественные пробелы
        name = ' '.join(name.split())
        
        return name.strip()
    
    def add_alias(self, league: str, canonical: str, alias: str):
        """Добавить новый alias (самообучение)"""
        if league not in self.aliases:
            self.aliases[league] = {}
        
        if canonical not in self.aliases[league]:
            self.aliases[league][canonical] = []
        
        alias_lower = alias.lower()
        if alias_lower not in self.aliases[league][canonical]:
            self.aliases[league][canonical].append(alias_lower)
            self._save_aliases()
            self._build_reverse_index()
    
    def fuzzy_match(self, name1: str, name2: str) -> int:
        """
        Fuzzy match двух названий.
        Возвращает score 0-100.
        """
        if not name1 or not name2:
            return 0
        
        # Нормализуем оба названия
        n1 = self.normalize(name1)
        n2 = self.normalize(name2)
        
        # Если после нормализации одинаковые - 100%
        if n1 == n2:
            return 100
        
        # Проверяем содержание (одно в другом)
        if n1 in n2 or n2 in n1:
            # Но только если короткое слово достаточно длинное (>= 5 символов)
            shorter = n1 if len(n1) < len(n2) else n2
            if len(shorter) >= 5:
                return 95
        
        # Fuzzy ratio - основной метод
        score = fuzz.ratio(n1, n2)
        
        # Token sort ratio - для случаев когда слова в разном порядке
        token_score = fuzz.token_sort_ratio(n1, n2)
        
        # Берем максимум из ratio и token_sort (но НЕ partial_ratio - он даёт ложные срабатывания)
        return max(score, token_score)
    
    def are_same_team(self, name1: str, name2: str, threshold: int = 80) -> bool:
        """Проверить, одна ли это команда"""
        return self.fuzzy_match(name1, name2) >= threshold


# Тест
if __name__ == "__main__":
    normalizer = TeamNormalizer()
    
    # Тесты нормализации
    tests = [
        ("Warriors", "nba"),
        ("Golden State Warriors", "nba"),
        ("GSW", "nba"),
        ("Timberwolves", "nba"),
        ("Minnesota Timberwolves", "nba"),
        ("Bruins", "nhl"),
        ("Boston Bruins", "nhl"),
        ("Laval Rocket", "ahl"),
        ("Calgary Wranglers", "ahl"),
    ]
    
    print("=== Тесты нормализации ===")
    for name, league in tests:
        normalized = normalizer.normalize(name, league)
        print(f"  {name} ({league}) -> {normalized}")
    
    print("\n=== Тесты fuzzy match ===")
    pairs = [
        ("Warriors", "Golden State Warriors"),
        ("Timberwolves", "Minnesota Timberwolves"),
        ("Bruins", "Boston Bruins"),
        ("Lakers", "Celtics"),
        ("Oklahoma", "Oklahoma Sooners"),
    ]
    
    for n1, n2 in pairs:
        score = normalizer.fuzzy_match(n1, n2)
        same = normalizer.are_same_team(n1, n2)
        print(f"  {n1} vs {n2}: score={score}, same={same}")
