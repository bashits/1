#!/usr/bin/env python3
"""
Matcher - главный класс модуля 2
Связывает события Kalshi и Polymarket
"""

import json
import os
import sys
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional, Tuple
from collections import defaultdict

# Добавляем путь к module1
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from module2.parser import EventParser
from module2.normalizer import TeamNormalizer
from module2.scorer import EventScorer
from module2.deepseek_judge import DeepSeekJudge


class EventMatcher:
    """Главный класс для матчинга событий между Kalshi и Polymarket"""
    
    def __init__(self, deepseek_api_key: str = None):
        self.parser = EventParser()
        self.normalizer = TeamNormalizer()
        self.scorer = EventScorer(self.normalizer)
        self.judge = DeepSeekJudge(deepseek_api_key)
        
        # Результаты
        self.links = []
        self.skipped = []
        self.stats = {
            'kalshi_total': 0,
            'poly_total': 0,
            'auto_linked': 0,
            'llm_linked': 0,
            'skipped': 0,
            'no_candidates': 0,
        }
    
    def match(self, kalshi_events: List[Dict], poly_events: List[Dict]) -> Dict:
        """
        Основной метод матчинга.
        
        Args:
            kalshi_events: список событий Kalshi (из module1)
            poly_events: список событий Polymarket (из module1)
        
        Returns:
            dict с результатами матчинга
        """
        print("\n" + "="*80)
        print("🔗 MODULE 2: EVENT MATCHER")
        print("="*80)
        
        self.stats['kalshi_total'] = len(kalshi_events)
        self.stats['poly_total'] = len(poly_events)
        
        print(f"📊 Kalshi событий: {len(kalshi_events)}")
        print(f"📊 Polymarket событий: {len(poly_events)}")
        
        # 1. Парсим все события
        print("\n🔍 Парсинг событий...")
        parsed_kalshi = [self.parser.parse_kalshi_event(e) for e in kalshi_events]
        parsed_poly = [self.parser.parse_polymarket_event(e) for e in poly_events]
        
        # 2. Группируем Polymarket по лиге для быстрого поиска
        poly_by_league = defaultdict(list)
        for p in parsed_poly:
            league = p.get('league', 'unknown')
            poly_by_league[league].append(p)
            poly_by_league['all'].append(p)  # Также добавляем в общий список
        
        print(f"   Polymarket по лигам: {dict((k, len(v)) for k, v in poly_by_league.items() if k != 'all')}")
        
        # 3. Для каждого события Kalshi ищем кандидатов
        print("\n🔗 Матчинг событий...")
        
        for i, k_event in enumerate(parsed_kalshi):
            if (i + 1) % 50 == 0:
                print(f"   Обработано: {i + 1}/{len(parsed_kalshi)}")
            
            # Ищем кандидатов
            candidates = self._find_candidates(k_event, poly_by_league)
            
            if not candidates:
                self.stats['no_candidates'] += 1
                self.skipped.append({
                    'kalshi': k_event,
                    'reason': 'no_candidates'
                })
                continue
            
            # Скорим кандидатов
            scored_candidates = []
            for cand in candidates:
                score, details = self.scorer.score(k_event, cand)
                scored_candidates.append((score, details, cand))
            
            # Сортируем по score
            scored_candidates.sort(key=lambda x: x[0], reverse=True)
            
            # Берем лучшего
            best_score, best_details, best_cand = scored_candidates[0]
            decision = self.scorer.get_decision(best_score)
            
            if decision == 'auto_link':
                # Автоматический LINK
                self._create_link(k_event, best_cand, best_score, best_details, 'auto')
                self.stats['auto_linked'] += 1
                
                # Самообучение отключено - добавляет неправильные aliases
                # if best_score >= 95:
                #     self._learn_alias(k_event, best_cand)
                pass
                
            elif decision == 'ask_llm':
                # Серая зона - линкуем только если score >= 75 (обе команды частично совпали)
                if best_score >= 75:
                    self._create_link(k_event, best_cand, best_score, best_details, 'medium')
                    self.stats['llm_linked'] += 1
                else:
                    self.stats['skipped'] += 1
                    self.skipped.append({
                        'kalshi': k_event,
                        'reason': 'gray_zone',
                        'best_score': best_score
                    })
            else:
                # Skip
                self.stats['skipped'] += 1
                self.skipped.append({
                    'kalshi': k_event,
                    'reason': 'low_score',
                    'best_score': best_score
                })
        
        # 4. Выводим статистику
        self._print_stats()
        
        return {
            'links': self.links,
            'skipped': self.skipped,
            'stats': self.stats
        }
    
    def _find_candidates(self, kalshi_event: Dict, poly_by_league: Dict) -> List[Dict]:
        """Найти кандидатов для события Kalshi"""
        candidates = []
        
        k_league = kalshi_event.get('league', 'unknown')
        k_time = kalshi_event.get('start_time')
        
        # Берем события той же лиги + unknown
        search_leagues = [k_league, 'unknown']
        if k_league == 'unknown':
            search_leagues = ['all']  # Если лига неизвестна, ищем везде
        
        for league in search_leagues:
            for p_event in poly_by_league.get(league, []):
                # Фильтр по времени (±6 часов)
                p_time = p_event.get('start_time')
                
                if k_time and p_time:
                    # Приводим к datetime
                    if isinstance(k_time, str):
                        try:
                            k_time_dt = datetime.fromisoformat(k_time.replace('Z', '+00:00'))
                        except:
                            k_time_dt = None
                    else:
                        k_time_dt = k_time
                    
                    if isinstance(p_time, str):
                        try:
                            p_time_dt = datetime.fromisoformat(p_time.replace('Z', '+00:00'))
                        except:
                            p_time_dt = None
                    else:
                        p_time_dt = p_time
                    
                    if k_time_dt and p_time_dt:
                        diff = abs((k_time_dt - p_time_dt).total_seconds() / 3600)
                        if diff > 6:  # Больше 6 часов - пропускаем
                            continue
                
                candidates.append(p_event)
        
        return candidates
    
    def _create_link(self, kalshi: Dict, poly: Dict, score: int, details: Dict, method: str):
        """Создать связку"""
        link = {
            'id': f"link_{len(self.links) + 1:04d}",
            'kalshi': {
                'ticker': kalshi.get('ticker', ''),
                'title': kalshi.get('original_title', ''),
                'team1': kalshi.get('team1', ''),
                'team2': kalshi.get('team2', ''),
                'league': kalshi.get('league', ''),
                'start_time': str(kalshi.get('start_time', '')),
                'market_type': kalshi.get('market_type', ''),
            },
            'polymarket': {
                'slug': poly.get('event_slug', ''),
                'title': poly.get('original_title', ''),
                'team1': poly.get('team1', ''),
                'team2': poly.get('team2', ''),
                'league': poly.get('league', ''),
                'start_time': str(poly.get('start_time', '')),
                'market_type': poly.get('market_type', ''),
            },
            'confidence': score,
            'method': method,
            'details': details,
            'linked_at': datetime.now(timezone.utc).isoformat()
        }
        
        self.links.append(link)
    
    def _learn_alias(self, kalshi: Dict, poly: Dict):
        """Самообучение: добавить alias если команды разные но матч точный"""
        k_team1 = kalshi.get('team1', '')
        k_team2 = kalshi.get('team2', '')
        p_team1 = poly.get('team1', '')
        p_team2 = poly.get('team2', '')
        league = kalshi.get('league', 'unknown')
        
        # Если названия разные, добавляем alias
        if k_team1 and p_team1 and k_team1 != p_team1:
            # Определяем какое название "каноническое"
            k_norm = self.normalizer.normalize(k_team1)
            p_norm = self.normalizer.normalize(p_team1)
            
            if k_norm != p_norm:
                # Добавляем p_team1 как alias для k_norm
                self.normalizer.add_alias(league, k_norm, p_team1)
    
    def _print_stats(self):
        """Вывести статистику"""
        total_linked = self.stats['auto_linked'] + self.stats['llm_linked']
        coverage = (total_linked / self.stats['kalshi_total'] * 100) if self.stats['kalshi_total'] > 0 else 0
        
        print("\n" + "="*80)
        print("📊 MATCHER STATISTICS")
        print("="*80)
        print(f"Kalshi событий:     {self.stats['kalshi_total']}")
        print(f"Polymarket событий: {self.stats['poly_total']}")
        print("-"*40)
        print(f"AUTO LINKED:        {self.stats['auto_linked']}")
        print(f"LLM LINKED:         {self.stats['llm_linked']}")
        print(f"TOTAL LINKED:       {total_linked}")
        print("-"*40)
        print(f"No candidates:      {self.stats['no_candidates']}")
        print(f"Skipped (low score):{self.stats['skipped']}")
        print("-"*40)
        print(f"COVERAGE:           {coverage:.1f}%")
        print("="*80)
    
    def save_links(self, filepath: str):
        """Сохранить связки в файл"""
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump({
                'links': self.links,
                'stats': self.stats,
                'generated_at': datetime.now(timezone.utc).isoformat()
            }, f, indent=2, ensure_ascii=False)
        print(f"\n💾 Links saved to: {filepath}")
    
    def print_links(self, max_show: int = 30):
        """Вывести связки"""
        print(f"\n🔗 LINKED EVENTS ({len(self.links)} total):")
        print("-"*80)
        
        for i, link in enumerate(self.links[:max_show], 1):
            k = link['kalshi']
            p = link['polymarket']
            
            print(f"{i:3}. [{link['confidence']:3}%] {link['method'].upper()}")
            print(f"     Kalshi:     {k['title']}")
            print(f"     Polymarket: {p['title']}")
            print(f"     League: {k['league']} | Time: {k['start_time'][:19]}")
            print()
        
        if len(self.links) > max_show:
            print(f"... и еще {len(self.links) - max_show} связок")


def main():
    """Тест на реальных данных"""
    # Импортируем module1
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from kalshi_listener import KalshiListener
    from polymarket_listener import PolymarketListener
    
    # DeepSeek API key
    DEEPSEEK_API_KEY = "sk-159f560c378d4dc4903c8d839d67483b"
    
    print("="*80)
    print("🤖 BOT 322 - MODULE 2 TEST")
    print("="*80)
    
    # 1. Получаем события из Module 1
    print("\n📥 Loading events from Module 1...")
    
    kalshi = KalshiListener(hours_ahead=6)
    kalshi_result = kalshi.run()
    
    polymarket = PolymarketListener(hours_ahead=6)
    poly_result = polymarket.run()
    
    # 2. Запускаем матчинг
    matcher = EventMatcher(deepseek_api_key=DEEPSEEK_API_KEY)
    result = matcher.match(kalshi_result['events'], poly_result['events'])
    
    # 3. Выводим результаты
    matcher.print_links()
    
    # 4. Сохраняем
    matcher.save_links('/workspace/project/322/links.json')
    
    return result


if __name__ == "__main__":
    main()
