#!/usr/bin/env python3
"""
Kalshi Live Games Listener - модуль для бота 322
Слушает LIVE спортивные игры на Kalshi - матчи на ближайшие 6 часов
"""

import requests
from datetime import datetime, timezone, timedelta
from typing import Optional, Dict, List
import json

KALSHI_API_URL = "https://api.elections.kalshi.com/trade-api/v2"


class KalshiListener:
    def __init__(self, hours_ahead: int = 6):
        self.hours_ahead = hours_ahead
        self.games: List[Dict] = []
        
    def get_current_time(self) -> datetime:
        return datetime.now(timezone.utc)
    
    def parse_time(self, time_str: Optional[str]) -> Optional[datetime]:
        if not time_str:
            return None
        try:
            return datetime.fromisoformat(time_str.replace('Z', '+00:00'))
        except:
            return None
    
    def fetch_all_events(self) -> List[Dict]:
        """Получить все открытые события"""
        all_events = []
        cursor = None
        max_pages = 30
        
        for page in range(max_pages):
            url = f"{KALSHI_API_URL}/events?limit=200&with_nested_markets=true&status=open"
            if cursor:
                url += f"&cursor={cursor}"
            
            try:
                resp = requests.get(url, timeout=30)
                if resp.status_code != 200:
                    break
                
                data = resp.json()
                events = data.get('events', [])
                all_events.extend(events)
                
                cursor = data.get('cursor')
                if not cursor or not events:
                    break
                    
            except Exception as e:
                print(f"  ❌ Kalshi error: {e}")
                break
        
        return all_events
    
    def filter_live_games(self, events: List[Dict]) -> List[Dict]:
        """Фильтровать только live спортивные игры на ближайшие N часов"""
        now = self.get_current_time()
        cutoff = now + timedelta(hours=self.hours_ahead)
        
        filtered = []
        seen_events = set()  # Дедупликация по event_ticker
        
        for event in events:
            category = event.get('category', '')
            
            # Только спортивные события
            if category != 'Sports':
                continue
            
            event_ticker = event.get('event_ticker', '')
            
            # Дедупликация по событию
            if event_ticker in seen_events:
                continue
            
            title = event.get('title', '')
            markets = event.get('markets', [])
            
            # Берем первый рынок для определения времени
            if not markets:
                continue
            
            market = markets[0]
            exp_time = self.parse_time(market.get('expected_expiration_time'))
            close_time = self.parse_time(market.get('close_time'))
            end_time = exp_time or close_time
            
            if not end_time:
                continue
            
            # Событие должно заканчиваться в ближайшие N часов
            if now < end_time <= cutoff:
                seen_events.add(event_ticker)
                hours_left = (end_time - now).total_seconds() / 3600
                
                # Собираем все рынки события
                event_markets = []
                for m in markets:
                    market_ticker = m.get('ticker', '')
                    ticker_upper = market_ticker.upper()
                    
                    if 'SPREAD' in ticker_upper:
                        market_type = 'SPREAD'
                    elif 'TOTAL' in ticker_upper or 'OVER' in ticker_upper:
                        market_type = 'TOTAL'
                    elif 'TD' in ticker_upper:
                        market_type = 'TOUCHDOWN'
                    else:
                        market_type = 'WINNER'
                    
                    event_markets.append({
                        'market_ticker': market_ticker,
                        'market_title': m.get('title', ''),
                        'market_type': market_type,
                        'yes_bid': m.get('yes_bid', 0),
                        'yes_ask': m.get('yes_ask', 0),
                        'no_bid': m.get('no_bid', 0),
                        'no_ask': m.get('no_ask', 0),
                        'last_price': m.get('last_price', 0),
                        'volume': m.get('volume', 0),
                        'yes_sub_title': m.get('yes_sub_title', ''),
                        'no_sub_title': m.get('no_sub_title', ''),
                    })
                
                filtered.append({
                    'source': 'kalshi',
                    'event_title': title,
                    'event_ticker': event_ticker,
                    'category': category,
                    'status': market.get('status', ''),
                    'end_time': end_time.isoformat(),
                    'end_time_dt': end_time,
                    'hours_left': hours_left,
                    'markets': event_markets,
                    'markets_count': len(event_markets),
                })
        
        filtered.sort(key=lambda x: x['hours_left'])
        return filtered
    
    def run(self) -> Dict:
        """Основной метод запуска"""
        print("\n🔍 Kalshi: загрузка событий...")
        all_events = self.fetch_all_events()
        print(f"   Всего событий: {len(all_events)}")
        
        live_games = self.filter_live_games(all_events)
        self.games = live_games
        
        # Подсчет рынков
        total_markets = sum(g['markets_count'] for g in live_games)
        
        return {
            'source': 'kalshi',
            'events': live_games,
            'events_count': len(live_games),
            'total_markets': total_markets
        }


def main():
    listener = KalshiListener(hours_ahead=6)
    result = listener.run()
    
    print(f"\n{'='*80}")
    print(f"KALSHI РЕЗУЛЬТАТ")
    print(f"{'='*80}")
    print(f"Событий на ближайшие 6ч: {result['events_count']}")
    print(f"Всего рынков: {result['total_markets']}")
    
    if result['events']:
        print(f"\n📋 События:")
        for i, g in enumerate(result['events'][:20], 1):
            print(f"  {i:2}. {g['event_title'][:50]}... | {g['hours_left']:.1f}ч | {g['markets_count']} рынков")
    
    return result


if __name__ == "__main__":
    main()
