#!/usr/bin/env python3
"""
BOT 322 - Main Module
Слушает LIVE спортивные события с Kalshi и Polymarket
Фильтр: события на ближайшие 6 часов
"""

from datetime import datetime, timezone
from kalshi_listener import KalshiListener
from polymarket_listener import PolymarketListener


def main():
    now = datetime.now(timezone.utc)
    
    print("="*80)
    print("🤖 BOT 322 - LIVE SPORTS EVENTS LISTENER")
    print("="*80)
    print(f"⏰ Текущее время UTC: {now.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"📅 Фильтр: события на ближайшие 6 часов")
    print("="*80)
    
    # === KALSHI ===
    print("\n" + "="*80)
    print("📊 KALSHI")
    print("="*80)
    
    kalshi = KalshiListener(hours_ahead=6)
    kalshi_result = kalshi.run()
    
    print(f"\n✅ Kalshi: {kalshi_result['events_count']} событий")
    print(f"   Всего рынков: {kalshi_result['total_markets']}")
    
    # === POLYMARKET ===
    print("\n" + "="*80)
    print("📊 POLYMARKET")
    print("="*80)
    
    polymarket = PolymarketListener(hours_ahead=6)
    poly_result = polymarket.run()
    
    print(f"\n✅ Polymarket: {poly_result['total_count']} событий")
    
    # === ИТОГОВЫЙ ОТЧЕТ ===
    print("\n" + "="*80)
    print("📋 ИТОГОВЫЙ ОТЧЕТ")
    print("="*80)
    print(f"⏰ Время: {now.strftime('%Y-%m-%d %H:%M:%S')} UTC")
    print(f"📅 Фильтр: ближайшие 6 часов")
    print("-"*80)
    print(f"KALSHI:")
    print(f"   Событий: {kalshi_result['events_count']}")
    print(f"   Рынков: {kalshi_result['total_markets']}")
    print(f"POLYMARKET:")
    print(f"   Событий: {poly_result['total_count']}")
    print("-"*80)
    print(f"ВСЕГО СОБЫТИЙ: {kalshi_result['events_count'] + poly_result['total_count']}")
    print("="*80)
    
    # Детальный вывод KALSHI (первые 30)
    if kalshi_result['events']:
        print(f"\n🏆 KALSHI СОБЫТИЯ ({kalshi_result['events_count']}):")
        print("-"*80)
        for i, g in enumerate(kalshi_result['events'][:30], 1):
            status = "🔴 LIVE" if g['hours_left'] <= 1 else ("🟡 СКОРО" if g['hours_left'] <= 3 else "⚪")
            print(f"{status} {i:2}. {g['event_title']}")
            print(f"       Конец: {g['end_time']} (через {g['hours_left']:.1f}ч) | {g['markets_count']} рынков")
            # Показываем первый рынок (основной)
            if g['markets']:
                m = g['markets'][0]
                yes = m['yes_sub_title'] or 'YES'
                no = m['no_sub_title'] or 'NO'
                print(f"       {yes}: {m['yes_bid']}¢ | {no}: {m['no_bid']}¢")
            print()
        if kalshi_result['events_count'] > 30:
            print(f"... и еще {kalshi_result['events_count'] - 30} событий")
    
    # Детальный вывод POLYMARKET (первые 30)
    if poly_result['events']:
        print(f"\n🏆 POLYMARKET СОБЫТИЯ ({poly_result['total_count']}):")
        print("-"*80)
        for i, e in enumerate(poly_result['events'][:30], 1):
            status = "🔴 LIVE" if e['hours_left'] <= 1 else ("🟡 СКОРО" if e['hours_left'] <= 3 else "⚪")
            vol = f"${e['volume']:,.0f}" if e['volume'] else "N/A"
            print(f"{status} {i:2}. {e['event_title']}")
            print(f"       Конец: {e['end_time']} (через {e['hours_left']:.1f}ч) | Объем: {vol}")
            if e['outcomes'] and e['prices']:
                odds = " | ".join([f"{o}: {float(p)*100:.0f}%" for o, p in zip(e['outcomes'], e['prices'])])
                print(f"       📊 {odds}")
            print()
        if poly_result['total_count'] > 30:
            print(f"... и еще {poly_result['total_count'] - 30} событий")
    
    return {
        'kalshi': kalshi_result,
        'polymarket': poly_result,
        'timestamp': now.isoformat()
    }


if __name__ == "__main__":
    main()
