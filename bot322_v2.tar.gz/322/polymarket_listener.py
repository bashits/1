#!/usr/bin/env python3
"""
Polymarket Sports Listener - модуль для бота 322
Слушает LIVE спортивные события на Polymarket - матчи на ближайшие 6 часов
"""

import requests
from datetime import datetime, timezone, timedelta
from typing import Optional, Dict, List
import json

GAMMA_API_URL = "https://gamma-api.polymarket.com"
DATA_API_URL = "https://data-api.polymarket.com"

# Tag IDs
SPORTS_TAG_ID = 1
GAME_BETS_TAG_ID = 100639  # Конкретные матчи


class PolymarketListener:
    def __init__(self, hours_ahead: int = 6):
        self.hours_ahead = hours_ahead
        self.events: List[Dict] = []
        self.markets_map: Dict[str, Dict] = {}
        
    def get_current_time(self) -> datetime:
        return datetime.now(timezone.utc)
    
    def parse_time(self, time_str: Optional[str]) -> Optional[datetime]:
        if not time_str:
            return None
        for fmt in [
            "%Y-%m-%dT%H:%M:%S.%fZ",
            "%Y-%m-%dT%H:%M:%SZ",
            "%Y-%m-%dT%H:%M:%S",
        ]:
            try:
                dt = datetime.strptime(time_str, fmt)
                return dt.replace(tzinfo=timezone.utc)
            except ValueError:
                continue
        return None
    
    def fetch_sports_events(self, max_events: int = 3000) -> List[Dict]:
        """Получить спортивные события (game bets)"""
        all_events = []
        offset = 0
        
        while len(all_events) < max_events:
            params = {
                'tag_id': GAME_BETS_TAG_ID,
                'active': 'true',
                'closed': 'false',
                'limit': 100,
                'offset': offset
            }
            
            try:
                response = requests.get(
                    f"{GAMMA_API_URL}/events",
                    params=params,
                    timeout=30
                )
                response.raise_for_status()
                events = response.json()
                
                if not events:
                    break
                    
                all_events.extend(events)
                
                if len(events) < 100:
                    break
                    
                offset += 100
                    
            except Exception as e:
                print(f"  ❌ Polymarket error: {e}")
                break
        
        return all_events
    
    def filter_live_and_upcoming(self, events: List[Dict]) -> List[Dict]:
        """Фильтровать события - только live или в ближайшие N часов"""
        now = self.get_current_time()
        cutoff = now + timedelta(hours=self.hours_ahead)
        
        filtered = []
        
        for event in events:
            end_date = self.parse_time(event.get('endDate'))
            
            if not end_date or end_date <= now:
                continue
            
            if end_date <= cutoff:
                hours_left = (end_date - now).total_seconds() / 3600
                
                markets = event.get('markets', [])
                
                # Получаем цены из первого рынка
                outcomes = []
                prices = []
                if markets:
                    market = markets[0]
                    try:
                        outcomes = json.loads(market.get('outcomes', '[]')) if isinstance(market.get('outcomes'), str) else market.get('outcomes', [])
                        prices = json.loads(market.get('outcomePrices', '[]')) if isinstance(market.get('outcomePrices'), str) else market.get('outcomePrices', [])
                    except:
                        pass
                
                filtered.append({
                    'source': 'polymarket',
                    'event_title': event.get('title', 'N/A'),
                    'event_slug': event.get('slug', ''),
                    'end_time': end_date.isoformat(),
                    'end_time_dt': end_date,
                    'hours_left': hours_left,
                    'volume': event.get('volume', 0),
                    'liquidity': event.get('liquidity', 0),
                    'markets_count': len(markets),
                    'outcomes': outcomes,
                    'prices': prices,
                    'condition_ids': [m.get('conditionId') for m in markets if m.get('conditionId')],
                })
        
        filtered.sort(key=lambda x: x['hours_left'])
        return filtered
    
    def build_markets_map(self, events: List[Dict]):
        """Построить карту рынков для быстрого поиска"""
        for event in events:
            for cid in event.get('condition_ids', []):
                self.markets_map[cid] = {
                    'event_title': event.get('event_title'),
                    'event_slug': event.get('event_slug'),
                }
    
    def run(self) -> Dict:
        """Основной метод запуска"""
        print("\n🔍 Polymarket: загрузка спортивных событий...")
        all_events = self.fetch_sports_events()
        print(f"   Всего спортивных событий: {len(all_events)}")
        
        live_events = self.filter_live_and_upcoming(all_events)
        self.events = live_events
        self.build_markets_map(live_events)
        
        return {
            'source': 'polymarket',
            'events': live_events,
            'total_count': len(live_events),
            'markets_map_size': len(self.markets_map)
        }


def main():
    listener = PolymarketListener(hours_ahead=6)
    result = listener.run()
    
    print(f"\n{'='*80}")
    print(f"POLYMARKET РЕЗУЛЬТАТ")
    print(f"{'='*80}")
    print(f"Спортивных событий на ближайшие 6ч: {result['total_count']}")
    
    if result['events']:
        print(f"\n📋 События:")
        for i, e in enumerate(result['events'][:20], 1):
            vol = f"${e['volume']:,.0f}" if e['volume'] else "N/A"
            print(f"  {i:2}. {e['event_title'][:50]}... | {e['hours_left']:.1f}ч | {vol}")
    
    return result


if __name__ == "__main__":
    main()
