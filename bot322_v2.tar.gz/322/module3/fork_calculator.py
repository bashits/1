#!/usr/bin/env python3
"""
Fork Calculator - расчёт вилок (арбитража) с учётом комиссий
"""

from typing import Dict, Optional, Tuple
from dataclasses import dataclass

from .config import KALSHI_FEE, POLYMARKET_FEE, TOTAL_FEE


@dataclass
class ForkResult:
    """Результат расчёта вилки"""
    has_fork: bool
    fork_percent: float  # Процент вилки (может быть отрицательным)
    best_strategy: str   # Описание лучшей стратегии
    kalshi_side: str     # 'YES' или 'NO' - что покупать на Kalshi
    poly_side: str       # 'YES' или 'NO' - что покупать на Polymarket
    kalshi_price: float  # Цена на Kalshi (0-1)
    poly_price: float    # Цена на Polymarket (0-1)
    total_cost: float    # Общая стоимость (0-2)
    gross_return: float  # Валовый возврат (1.0)
    net_return: float    # Чистый возврат после комиссий
    profit: float        # Профит (может быть отрицательным)


class ForkCalculator:
    """Калькулятор вилок между Kalshi и Polymarket"""
    
    def __init__(self, kalshi_fee: float = KALSHI_FEE, poly_fee: float = POLYMARKET_FEE):
        self.kalshi_fee = kalshi_fee
        self.poly_fee = poly_fee
        self.total_fee = kalshi_fee + poly_fee
    
    def calculate(self, kalshi_prices: Dict, poly_prices: Dict) -> Optional[ForkResult]:
        """
        Рассчитать лучшую вилку между Kalshi и Polymarket.
        
        Args:
            kalshi_prices: {'yes_bid': float, 'yes_ask': float, 'no_bid': float, 'no_ask': float}
            poly_prices: {'yes_price': float, 'no_price': float}
        
        Returns:
            ForkResult с лучшей стратегией
        """
        if not kalshi_prices or not poly_prices:
            return None
        
        # Получаем цены
        # Для покупки используем ASK (или price если ask недоступен)
        # Для Kalshi: yes_ask = цена покупки YES, no_ask = цена покупки NO
        k_yes = kalshi_prices.get('yes_ask') or kalshi_prices.get('yes_bid', 0.5)
        k_no = kalshi_prices.get('no_ask') or kalshi_prices.get('no_bid', 0.5)
        
        # Для Polymarket используем price напрямую
        p_yes = poly_prices.get('yes_price', 0.5)
        p_no = poly_prices.get('no_price', 0.5)
        
        # Если цены нулевые или некорректные, пропускаем
        if k_yes <= 0 or k_no <= 0 or p_yes <= 0 or p_no <= 0:
            return None
        
        # Рассчитываем 4 варианта:
        # 1. Kalshi YES + Polymarket NO
        # 2. Kalshi NO + Polymarket YES
        
        strategies = []
        
        # Стратегия 1: Kalshi YES + Poly NO
        cost1 = k_yes + p_no
        net_return1 = 1.0 * (1 - self.total_fee)
        profit1 = net_return1 - cost1
        fork_pct1 = (profit1 / cost1) * 100 if cost1 > 0 else -100
        
        strategies.append({
            'kalshi_side': 'YES',
            'poly_side': 'NO',
            'kalshi_price': k_yes,
            'poly_price': p_no,
            'cost': cost1,
            'net_return': net_return1,
            'profit': profit1,
            'fork_pct': fork_pct1,
        })
        
        # Стратегия 2: Kalshi NO + Poly YES
        cost2 = k_no + p_yes
        net_return2 = 1.0 * (1 - self.total_fee)
        profit2 = net_return2 - cost2
        fork_pct2 = (profit2 / cost2) * 100 if cost2 > 0 else -100
        
        strategies.append({
            'kalshi_side': 'NO',
            'poly_side': 'YES',
            'kalshi_price': k_no,
            'poly_price': p_yes,
            'cost': cost2,
            'net_return': net_return2,
            'profit': profit2,
            'fork_pct': fork_pct2,
        })
        
        # Выбираем лучшую стратегию (максимальный профит)
        best = max(strategies, key=lambda x: x['fork_pct'])
        
        return ForkResult(
            has_fork=best['profit'] > 0,
            fork_percent=best['fork_pct'],
            best_strategy=f"Kalshi {best['kalshi_side']} ({best['kalshi_price']:.2%}) + Poly {best['poly_side']} ({best['poly_price']:.2%})",
            kalshi_side=best['kalshi_side'],
            poly_side=best['poly_side'],
            kalshi_price=best['kalshi_price'],
            poly_price=best['poly_price'],
            total_cost=best['cost'],
            gross_return=1.0,
            net_return=best['net_return'],
            profit=best['profit'],
        )
    
    def calculate_simple(self, k_yes: float, k_no: float, p_yes: float, p_no: float) -> ForkResult:
        """
        Упрощённый расчёт вилки.
        
        Args:
            k_yes: Kalshi YES price (0-1)
            k_no: Kalshi NO price (0-1)
            p_yes: Polymarket YES price (0-1)
            p_no: Polymarket NO price (0-1)
        """
        return self.calculate(
            {'yes_ask': k_yes, 'no_ask': k_no},
            {'yes_price': p_yes, 'no_price': p_no}
        )


# Тест
if __name__ == "__main__":
    calc = ForkCalculator()
    
    # Тест 1: Положительная вилка
    print("Test 1: Positive fork")
    result = calc.calculate_simple(0.40, 0.60, 0.55, 0.45)
    if result:
        print(f"  Fork: {result.fork_percent:+.2f}%")
        print(f"  Strategy: {result.best_strategy}")
        print(f"  Cost: {result.total_cost:.2%}, Return: {result.net_return:.2%}")
        print(f"  Profit: {result.profit:.2%}")
        print(f"  Has fork: {result.has_fork}")
    
    # Тест 2: Отрицательная вилка (нет арбитража)
    print("\nTest 2: Negative fork")
    result = calc.calculate_simple(0.50, 0.50, 0.50, 0.50)
    if result:
        print(f"  Fork: {result.fork_percent:+.2f}%")
        print(f"  Strategy: {result.best_strategy}")
        print(f"  Has fork: {result.has_fork}")
    
    # Тест 3: Реальные цены
    print("\nTest 3: Real-ish prices")
    result = calc.calculate_simple(0.54, 0.46, 0.52, 0.48)
    if result:
        print(f"  Fork: {result.fork_percent:+.2f}%")
        print(f"  Strategy: {result.best_strategy}")
        print(f"  Has fork: {result.has_fork}")
