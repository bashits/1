#!/usr/bin/env python3
"""
Fork Tracker - главный модуль отслеживания вилок в реальном времени
"""

import os
import sys
import json
import time
from datetime import datetime, timezone
from typing import Dict, List, Optional

# Добавляем путь к корню проекта
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from module3.prices_fetcher import PricesFetcher
from module3.fork_calculator import ForkCalculator, ForkResult
from module3.validator import MatchValidator
from module3.config import (
    UPDATE_INTERVAL, POSITIVE_FORK_THRESHOLD, HOT_FORK_THRESHOLD,
    Colors, TOTAL_FEE
)


class ForkTracker:
    """Главный класс отслеживания вилок"""
    
    def __init__(self, links_file: str = None, validate: bool = True):
        self.fetcher = PricesFetcher()
        self.calculator = ForkCalculator()
        self.validator = MatchValidator() if validate else None
        self.links = []
        self.kalshi_events = {}  # event_ticker -> event data with markets
        self.poly_events = {}    # slug -> event data
        self.stats = {
            'total_checks': 0,
            'positive_forks': 0,
            'best_fork': -100,
            'best_fork_event': '',
            'invalid_matches': 0,
        }
        
        # Кэш результатов для умного обновления
        self.last_results = {}  # link_id -> {result, fork_percent, last_update}
        self.positive_links = set()  # ID связок с положительной вилкой
        self.negative_update_interval = 5  # Обновлять минусовые раз в 5 сек
        self.invalid_links = set()  # ID невалидных связок (не проверять)
        self.validated_links = set()  # ID уже проверенных валидных связок
        
        # Загружаем связки
        if links_file:
            self.load_links(links_file)
    
    def load_links(self, filepath: str):
        """Загрузить связки из файла модуля 2"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.links = data.get('links', [])
                print(f"✅ Загружено {len(self.links)} связок из {filepath}")
        except Exception as e:
            print(f"❌ Ошибка загрузки связок: {e}")
            self.links = []
    
    def load_fresh_data(self):
        """Загрузить свежие данные из модуля 1 и 2 с полными ценами"""
        from kalshi_listener import KalshiListener
        from polymarket_listener import PolymarketListener
        from module2.matcher import EventMatcher
        
        print("📥 Загрузка событий из Module 1...")
        
        kalshi = KalshiListener(hours_ahead=6)
        kalshi_result = kalshi.run()
        
        polymarket = PolymarketListener(hours_ahead=6)
        poly_result = polymarket.run()
        
        # Сохраняем события с ценами
        for event in kalshi_result['events']:
            ticker = event.get('event_ticker', '')
            if ticker:
                self.kalshi_events[ticker] = event
        
        for event in poly_result['events']:
            slug = event.get('event_slug', '')
            if slug:
                self.poly_events[slug] = event
        
        print(f"   Kalshi событий с ценами: {len(self.kalshi_events)}")
        print(f"   Polymarket событий с ценами: {len(self.poly_events)}")
        
        print("🔗 Матчинг событий (Module 2)...")
        matcher = EventMatcher()
        result = matcher.match(kalshi_result['events'], poly_result['events'])
        
        self.links = result['links']
        print(f"✅ Получено {len(self.links)} связок")
        
        return result
    
    def load_links_from_module2(self):
        """Загрузить связки напрямую из модуля 2"""
        return self.load_fresh_data()
    
    def get_unique_events(self) -> List[Dict]:
        """Получить уникальные события (без дубликатов рынков)"""
        unique = {}
        
        for link in self.links:
            k_title = link['kalshi']['title']
            p_slug = link['polymarket']['slug']
            
            # Убираем суффиксы типа ': Points', ': Anytime Goal'
            k_base = k_title.split(':')[0].strip() if ':' in k_title else k_title
            
            key = (k_base, p_slug)
            if key not in unique:
                unique[key] = link
        
        return list(unique.values())
    
    def track_single(self, link: Dict) -> Optional[Dict]:
        """
        Отследить одну связку и вернуть результат.
        КАЖДЫЙ РАЗ делает запросы к API за СВЕЖИМИ ценами!
        """
        k = link['kalshi']
        p = link['polymarket']
        
        link_id = link.get('id', k.get('ticker', ''))
        
        # Пропускаем уже проверенные невалидные связки
        if link_id in self.invalid_links:
            return None
        
        k_ticker = k.get('ticker', '')
        p_slug = p.get('slug', '')
        k_title = k.get('title', '')
        p_title = p.get('title', '')
        
        # === ВАЛИДАЦИЯ ПРИ ПЕРВОМ ПОЯВЛЕНИИ ===
        # Проверяем КАЖДУЮ новую связку через DeepSeek ОДИН РАЗ
        if link_id not in self.validated_links:
            # 1. Быстрая проверка типа рынка (Points vs Winner)
            if self.validator and not self.validator.quick_validate(k_title, p_title):
                self.invalid_links.add(link_id)
                self.stats['invalid_matches'] += 1
                print(f"   ❌ Filtered (market type): {k_title[:40]}")
                return None
            
            # 2. Полная проверка через DeepSeek
            if self.validator and self.validator.client:
                is_valid, reason = self.validator.validate_match(
                    k_title, p_title,
                    k.get('league', ''), p.get('league', '')
                )
                if not is_valid:
                    self.invalid_links.add(link_id)
                    self.stats['invalid_matches'] += 1
                    print(f"   ❌ Invalid: {k_title[:35]} vs {p_title[:35]}")
                    print(f"      Reason: {reason[:60]}")
                    return None
                else:
                    print(f"   ✅ Validated: {k_title[:50]}")
            
            # Помечаем как проверенную
            self.validated_links.add(link_id)
        
        # Получаем market_ticker из сохранённых данных
        market_ticker = link.get('kalshi_market_ticker', '')
        
        # === KALSHI: получаем СВЕЖИЕ цены через API ===
        kalshi_prices = None
        
        # Способ 1: если есть market_ticker - используем его напрямую
        if market_ticker:
            kalshi_prices = self.fetcher.fetch_kalshi_market(market_ticker)
        
        # Способ 2: если есть event_ticker - получаем все рынки события
        if not kalshi_prices and k_ticker:
            kalshi_markets = self.fetcher.fetch_kalshi_event_markets(k_ticker)
            if kalshi_markets and len(kalshi_markets) > 0:
                m = kalshi_markets[0]
                kalshi_prices = {
                    'yes_bid': m.get('yes_bid', 0),
                    'yes_ask': m.get('yes_ask', 0),
                    'no_bid': m.get('no_bid', 0),
                    'no_ask': m.get('no_ask', 0),
                }
        
        # Способ 3: используем кэшированные данные из модуля 1 (fallback)
        if not kalshi_prices and k_ticker in self.kalshi_events:
            event = self.kalshi_events[k_ticker]
            markets = event.get('markets', [])
            if markets:
                m = markets[0]
                kalshi_prices = {
                    'yes_bid': m.get('yes_bid', 0) / 100 if m.get('yes_bid', 0) > 1 else m.get('yes_bid', 0),
                    'yes_ask': m.get('yes_ask', 0) / 100 if m.get('yes_ask', 0) > 1 else m.get('yes_ask', 0),
                    'no_bid': m.get('no_bid', 0) / 100 if m.get('no_bid', 0) > 1 else m.get('no_bid', 0),
                    'no_ask': m.get('no_ask', 0) / 100 if m.get('no_ask', 0) > 1 else m.get('no_ask', 0),
                }
        
        # === POLYMARKET: получаем СВЕЖИЕ цены через API ===
        poly_prices = None
        
        # Способ 1: через slug
        if p_slug:
            poly_prices = self.fetcher.fetch_polymarket_by_slug(p_slug)
        
        # Способ 2: через condition_id
        if not poly_prices:
            condition_ids = link.get('polymarket_condition_ids', [])
            if condition_ids:
                poly_prices = self.fetcher.fetch_polymarket_by_condition(condition_ids[0])
        
        # Способ 3: используем кэшированные данные из модуля 1 (fallback)
        if not poly_prices and p_slug in self.poly_events:
            event = self.poly_events[p_slug]
            prices = event.get('prices', [])
            if len(prices) >= 2:
                poly_prices = {
                    'yes_price': float(prices[0]),
                    'no_price': float(prices[1]),
                }
        
        # Если нет цен - пропускаем
        if not kalshi_prices or not poly_prices:
            return None
        
        # Рассчитываем вилку
        fork_result = self.calculator.calculate(kalshi_prices, poly_prices)
        
        if not fork_result:
            return None
        
        return {
            'kalshi_title': k_title,
            'poly_title': p_title,
            'league': k.get('league', 'unknown'),
            'kalshi_prices': kalshi_prices,
            'poly_prices': poly_prices,
            'fork': fork_result,
        }
    
    def print_header(self):
        """Вывести заголовок"""
        now = datetime.now(timezone.utc)
        print("\033[2J\033[H", end="")  # Очистка экрана
        print("=" * 100)
        print(f"{Colors.BOLD}🔍 FORK TRACKER - Module 3{Colors.RESET}")
        print(f"⏰ {now.strftime('%Y-%m-%d %H:%M:%S')} UTC | Комиссия: {TOTAL_FEE*100:.1f}%")
        print("=" * 100)
    
    def print_event(self, result: Dict, index: int):
        """Вывести информацию о событии"""
        fork = result['fork']
        k_prices = result['kalshi_prices']
        p_prices = result['poly_prices']
        
        # Определяем цвет и статус
        if fork.fork_percent >= HOT_FORK_THRESHOLD:
            color = Colors.GREEN
            status = "🔥 HOT FORK"
            emoji = "🔥🔥🔥"
        elif fork.fork_percent >= POSITIVE_FORK_THRESHOLD:
            color = Colors.GREEN
            status = "✅ POSITIVE"
            emoji = "✅"
        elif fork.fork_percent >= -2:
            color = Colors.YELLOW
            status = "⚠️ CLOSE"
            emoji = "⚠️"
        else:
            color = Colors.RED
            status = "❌ NEGATIVE"
            emoji = "❌"
        
        # Иконка лиги
        league_icons = {
            'nba': '🏀',
            'nhl': '🏒',
            'nfl': '🏈',
            'mlb': '⚾',
            'ncaa': '🎓',
            'ahl': '🏒',
            'soccer': '⚽',
            'esports': '🎮',
            'mma': '🥊',
        }
        league_icon = league_icons.get(result['league'].lower(), '🎯')
        
        # Форматируем цены
        k_yes = k_prices.get('yes_ask') or k_prices.get('yes_bid', 0)
        k_no = k_prices.get('no_ask') or k_prices.get('no_bid', 0)
        p_yes = p_prices.get('yes_price', 0)
        p_no = p_prices.get('no_price', 0)
        
        print(f"\n{league_icon} {Colors.BOLD}{result['kalshi_title'][:60]}{Colors.RESET}")
        print(f"   Kalshi:     YES={k_yes*100:5.1f}¢  NO={k_no*100:5.1f}¢")
        print(f"   Polymarket: YES={p_yes*100:5.1f}%  NO={p_no*100:5.1f}%")
        print(f"   Лучшая: {fork.best_strategy} = {fork.total_cost*100:.1f}%")
        print(f"   {color}📈 ВИЛКА: {fork.fork_percent:+.2f}% {status} {emoji}{Colors.RESET}")
    
    def print_summary(self, results: List[Dict]):
        """Вывести итоговую статистику"""
        positive = [r for r in results if r['fork'].fork_percent >= POSITIVE_FORK_THRESHOLD]
        
        print("\n" + "-" * 100)
        
        if positive:
            best = max(positive, key=lambda x: x['fork'].fork_percent)
            print(f"{Colors.GREEN}📊 ПОЛОЖИТЕЛЬНЫХ ВИЛОК: {len(positive)}{Colors.RESET}")
            print(f"   Лучшая: {best['kalshi_title'][:40]} = {Colors.GREEN}{best['fork'].fork_percent:+.2f}%{Colors.RESET}")
        else:
            print(f"{Colors.YELLOW}📊 Положительных вилок нет{Colors.RESET}")
        
        # Обновляем статистику
        self.stats['total_checks'] += 1
        if positive:
            self.stats['positive_forks'] += len(positive)
            best_fork = max(r['fork'].fork_percent for r in positive)
            if best_fork > self.stats['best_fork']:
                self.stats['best_fork'] = best_fork
                self.stats['best_fork_event'] = best['kalshi_title']
        
        invalid_str = f" | ❌ Отфильтровано: {self.stats['invalid_matches']}" if self.stats['invalid_matches'] > 0 else ""
        print(f"   Всего проверок: {self.stats['total_checks']} | "
              f"Найдено вилок: {self.stats['positive_forks']} | "
              f"Лучшая за сессию: {self.stats['best_fork']:+.2f}%{invalid_str}")
        print("=" * 100)
    
    def run_once(self, iteration: int = 0) -> List[Dict]:
        """
        Выполнить одну итерацию проверки - УМНОЕ обновление:
        - Плюсовые вилки: каждую секунду
        - Минусовые вилки: раз в 5 секунд
        """
        results = []
        now = time.time()
        
        # Очищаем кэш fetcher'а
        self.fetcher.clear_cache()
        
        # Получаем уникальные события
        unique_events = self.get_unique_events()
        
        for link in unique_events:
            link_id = link.get('id', link['kalshi'].get('ticker', ''))
            
            # Проверяем нужно ли обновлять эту связку
            cached = self.last_results.get(link_id)
            
            if cached:
                last_fork = cached.get('fork_percent', -100)
                last_update = cached.get('last_update', 0)
                time_since_update = now - last_update
                
                # Если вилка была отрицательная и прошло меньше 5 сек - используем кэш
                if last_fork < POSITIVE_FORK_THRESHOLD and time_since_update < self.negative_update_interval:
                    # Используем кэшированный результат
                    if cached.get('result'):
                        results.append(cached['result'])
                    continue
            
            # Получаем свежие данные
            result = self.track_single(link)
            
            if result:
                results.append(result)
                fork_pct = result['fork'].fork_percent
                
                # Сохраняем в кэш
                self.last_results[link_id] = {
                    'result': result,
                    'fork_percent': fork_pct,
                    'last_update': now,
                }
                
                # Обновляем список положительных
                if fork_pct >= POSITIVE_FORK_THRESHOLD:
                    self.positive_links.add(link_id)
                else:
                    self.positive_links.discard(link_id)
        
        return results
    
    def run(self, duration: int = None, show_all: bool = False):
        """
        Запустить трекер.
        
        Args:
            duration: Длительность в секундах (None = бесконечно)
            show_all: Показывать все события или только с вилками
        """
        if not self.links:
            print("❌ Нет связок для отслеживания!")
            return
        
        unique_count = len(self.get_unique_events())
        print(f"\n🚀 Запуск трекера для {unique_count} уникальных событий...")
        print(f"   Интервал обновления: {UPDATE_INTERVAL} сек")
        print(f"   Плюсовые вилки: каждую секунду | Минусовые: раз в {self.negative_update_interval} сек")
        print(f"   Нажмите Ctrl+C для остановки\n")
        
        start_time = time.time()
        iteration = 0
        
        try:
            while True:
                iteration += 1
                iter_start = time.time()
                
                # Проверяем длительность
                if duration and (time.time() - start_time) >= duration:
                    print(f"\n⏱️ Время вышло ({duration} сек)")
                    break
                
                # Выполняем проверку
                self.print_header()
                
                # Считаем сколько будет обновлено
                fresh_count = len(self.positive_links) + (1 if iteration % self.negative_update_interval == 0 else 0)
                print(f"📡 Итерация #{iteration} | События: {unique_count} | Свежих запросов: ~{len(self.positive_links) + (unique_count - len(self.positive_links)) // self.negative_update_interval}")
                
                results = self.run_once(iteration)
                
                if not results:
                    print(f"\n{Colors.YELLOW}⚠️ Не удалось получить цены{Colors.RESET}")
                else:
                    # Сортируем по проценту вилки
                    results.sort(key=lambda x: x['fork'].fork_percent, reverse=True)
                    
                    # Выводим события
                    if show_all:
                        for i, r in enumerate(results, 1):
                            self.print_event(r, i)
                    else:
                        # Показываем только топ-10 и положительные
                        shown = 0
                        for i, r in enumerate(results, 1):
                            if r['fork'].fork_percent >= POSITIVE_FORK_THRESHOLD or shown < 10:
                                self.print_event(r, i)
                                shown += 1
                        
                        if len(results) > shown:
                            print(f"\n   ... и ещё {len(results) - shown} событий с отрицательной вилкой")
                    
                    self.print_summary(results)
                
                # Ждём следующую итерацию (учитываем время выполнения)
                iter_time = time.time() - iter_start
                sleep_time = max(0, UPDATE_INTERVAL - iter_time)
                if sleep_time > 0:
                    time.sleep(sleep_time)
                
        except KeyboardInterrupt:
            print(f"\n\n🛑 Остановлено пользователем")
            print(f"   Всего итераций: {iteration}")
            print(f"   Найдено положительных вилок: {self.stats['positive_forks']}")
            if self.stats['best_fork'] > -100:
                print(f"   Лучшая вилка: {self.stats['best_fork']:+.2f}% ({self.stats['best_fork_event'][:40]})")


def main():
    """Главная функция"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Fork Tracker - Module 3')
    parser.add_argument('--links', '-l', type=str, help='Путь к файлу связок (links.json)')
    parser.add_argument('--duration', '-d', type=int, help='Длительность в секундах')
    parser.add_argument('--all', '-a', action='store_true', help='Показывать все события')
    parser.add_argument('--fresh', '-f', action='store_true', help='Загрузить свежие данные из Module 1+2')
    
    args = parser.parse_args()
    
    tracker = ForkTracker()
    
    if args.fresh:
        # Загружаем свежие данные
        tracker.load_links_from_module2()
    elif args.links:
        # Загружаем из файла
        tracker.load_links(args.links)
    else:
        # Пробуем найти файл по умолчанию
        default_paths = [
            'links_test.json',
            'links.json',
            '/workspace/project/11/322/links_test.json',
            '/workspace/project/11/322/links.json',
        ]
        for path in default_paths:
            if os.path.exists(path):
                tracker.load_links(path)
                break
        
        if not tracker.links:
            print("⚠️ Файл связок не найден. Загружаю свежие данные...")
            tracker.load_links_from_module2()
    
    # Запускаем трекер
    tracker.run(duration=args.duration, show_all=args.all)


if __name__ == "__main__":
    main()
