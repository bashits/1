#!/usr/bin/env python3
"""
Prices Fetcher - получение цен в реальном времени с Kalshi и Polymarket
НЕЗАВИСИМЫЙ модуль - сам долбит API каждую секунду
"""

import requests
from typing import Dict, Optional, List
from datetime import datetime, timezone
import time
import json

from .config import KALSHI_API_URL, POLYMARKET_CLOB_API, POLYMARKET_GAMMA_API, API_TIMEOUT


class PricesFetcher:
    """Получение СВЕЖИХ цен с Kalshi и Polymarket каждую секунду"""
    
    def __init__(self):
        self.session = requests.Session()
        # Минимальный кэш только для дедупликации в рамках одной секунды
        self.cache = {}
        self.cache_ttl = 0.3  # 300ms - защита от дублей в одной итерации
        
    def fetch_kalshi_market(self, market_ticker: str) -> Optional[Dict]:
        """
        Получить СВЕЖИЕ цены с Kalshi для конкретного market_ticker.
        Делает реальный запрос к API!
        """
        cache_key = f"kalshi_m_{market_ticker}"
        cached = self._get_cached(cache_key)
        if cached:
            return cached
        
        try:
            url = f"{KALSHI_API_URL}/markets/{market_ticker}"
            resp = self.session.get(url, timeout=API_TIMEOUT)
            
            if resp.status_code != 200:
                return None
            
            data = resp.json()
            market = data.get('market', {})
            
            # Kalshi возвращает цены в центах (0-100)
            result = {
                'yes_bid': market.get('yes_bid', 0) / 100,
                'yes_ask': market.get('yes_ask', 0) / 100,
                'no_bid': market.get('no_bid', 0) / 100,
                'no_ask': market.get('no_ask', 0) / 100,
                'last_price': market.get('last_price', 0) / 100,
                'volume': market.get('volume', 0),
                'status': market.get('status', ''),
            }
            
            self._set_cached(cache_key, result)
            return result
            
        except Exception as e:
            return None
    
    def fetch_kalshi_event_markets(self, event_ticker: str) -> Optional[List[Dict]]:
        """
        Получить СВЕЖИЕ цены всех рынков события Kalshi.
        Делает реальный запрос к API!
        """
        cache_key = f"kalshi_e_{event_ticker}"
        cached = self._get_cached(cache_key)
        if cached:
            return cached
        
        try:
            url = f"{KALSHI_API_URL}/events/{event_ticker}"
            resp = self.session.get(url, timeout=API_TIMEOUT)
            
            if resp.status_code != 200:
                return None
            
            data = resp.json()
            event = data.get('event', {})
            markets = event.get('markets', [])
            
            result = []
            for m in markets:
                result.append({
                    'ticker': m.get('ticker', ''),
                    'title': m.get('title', ''),
                    'yes_bid': m.get('yes_bid', 0) / 100,
                    'yes_ask': m.get('yes_ask', 0) / 100,
                    'no_bid': m.get('no_bid', 0) / 100,
                    'no_ask': m.get('no_ask', 0) / 100,
                    'last_price': m.get('last_price', 0) / 100,
                    'volume': m.get('volume', 0),
                    'yes_sub_title': m.get('yes_sub_title', ''),
                    'no_sub_title': m.get('no_sub_title', ''),
                })
            
            self._set_cached(cache_key, result)
            return result
            
        except Exception as e:
            return None
    
    def fetch_polymarket_by_slug(self, slug: str) -> Optional[Dict]:
        """
        Получить СВЕЖИЕ цены с Polymarket по slug.
        Делает реальный запрос к API!
        """
        cache_key = f"poly_s_{slug}"
        cached = self._get_cached(cache_key)
        if cached:
            return cached
        
        try:
            url = f"{POLYMARKET_GAMMA_API}/events"
            params = {'slug': slug}
            resp = self.session.get(url, params=params, timeout=API_TIMEOUT)
            
            if resp.status_code != 200:
                return None
            
            events = resp.json()
            if not events or len(events) == 0:
                return None
            
            event = events[0]
            markets = event.get('markets', [])
            if not markets:
                return None
            
            market = markets[0]
            prices_str = market.get('outcomePrices', '[]')
            if isinstance(prices_str, str):
                prices = json.loads(prices_str)
            else:
                prices = prices_str
            
            yes_price = float(prices[0]) if len(prices) > 0 else 0.5
            no_price = float(prices[1]) if len(prices) > 1 else 0.5
            
            result = {
                'yes_price': yes_price,
                'no_price': no_price,
            }
            
            self._set_cached(cache_key, result)
            return result
            
        except Exception as e:
            return None
    
    def fetch_polymarket_by_condition(self, condition_id: str) -> Optional[Dict]:
        """
        Получить СВЕЖИЕ цены с Polymarket по condition_id.
        """
        cache_key = f"poly_c_{condition_id}"
        cached = self._get_cached(cache_key)
        if cached:
            return cached
        
        try:
            url = f"{POLYMARKET_GAMMA_API}/markets"
            params = {'condition_id': condition_id}
            resp = self.session.get(url, params=params, timeout=API_TIMEOUT)
            
            if resp.status_code != 200:
                return None
            
            markets = resp.json()
            if not markets or len(markets) == 0:
                return None
            
            market = markets[0]
            prices_str = market.get('outcomePrices', '[]')
            if isinstance(prices_str, str):
                prices = json.loads(prices_str)
            else:
                prices = prices_str
            
            yes_price = float(prices[0]) if len(prices) > 0 else 0.5
            no_price = float(prices[1]) if len(prices) > 1 else 0.5
            
            result = {
                'yes_price': yes_price,
                'no_price': no_price,
            }
            
            self._set_cached(cache_key, result)
            return result
            
        except Exception as e:
            return None
    
    def clear_cache(self):
        """Очистить кэш для получения совсем свежих данных"""
        self.cache = {}
    
    def _get_cached(self, key: str) -> Optional[Dict]:
        """Получить из кэша если не истёк (очень короткий TTL)"""
        if key in self.cache:
            data, timestamp = self.cache[key]
            if time.time() - timestamp < self.cache_ttl:
                return data
        return None
    
    def _set_cached(self, key: str, data: Dict):
        """Сохранить в кэш"""
        self.cache[key] = (data, time.time())
    
    # Алиасы для совместимости
    def fetch_kalshi_prices(self, market_ticker: str) -> Optional[Dict]:
        return self.fetch_kalshi_market(market_ticker)
    
    def fetch_kalshi_event_prices(self, event_ticker: str) -> Optional[List[Dict]]:
        return self.fetch_kalshi_event_markets(event_ticker)
    
    def fetch_polymarket_prices(self, token_id: str = None, condition_id: str = None, slug: str = None) -> Optional[Dict]:
        if slug:
            return self.fetch_polymarket_by_slug(slug)
        if condition_id:
            return self.fetch_polymarket_by_condition(condition_id)
        return None


# Тест
if __name__ == "__main__":
    fetcher = PricesFetcher()
    
    # Тест Kalshi
    print("Testing Kalshi...")
    kalshi_prices = fetcher.fetch_kalshi_event_prices("KXNHLGAME-26JAN25-TBLCBJ")
    if kalshi_prices:
        print(f"  Found {len(kalshi_prices)} markets")
        for m in kalshi_prices[:3]:
            print(f"    {m['ticker']}: YES={m['yes_bid']:.2f}/{m['yes_ask']:.2f}")
    else:
        print("  No data")
    
    # Тест Polymarket
    print("\nTesting Polymarket...")
    poly_prices = fetcher.fetch_polymarket_by_slug("lightning-vs-blue-jackets")
    if poly_prices:
        print(f"  YES={poly_prices.get('yes_price', 0):.2f}, NO={poly_prices.get('no_price', 0):.2f}")
    else:
        print("  No data")
